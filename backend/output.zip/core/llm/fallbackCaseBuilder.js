/**
 * fallbackCaseBuilder.js
 *
 * Purpose:
 * Generates safe fallback invariant test cases when LLM candidates are rejected
 * or fail runtime validation.
 *
 * These fallback cases are NOT prototypes.
 * They are injected into the LLM marker area as extra generated tests.
 *
 * Design goals:
 * - increase injected test count safely
 * - improve fallback quality beyond generic toBeDefined checks
 * - use function source to infer likely return shape
 * - support normal functions, class constructors, static methods, and prototype methods
 * - avoid fabricated exact expected outputs
 * - avoid package-specific hardcoding
 * - avoid real filesystem/network/database access
 * - keep assertions broad but meaningful
 * - work for general JavaScript/npm package functions
 */

const RESERVED_NAMES = new Set([
  "result",
  "expect",
  "test",
  "describe",
  "jest",
  "mod",
  "undefined",
  "null",
  "NaN",
  "Infinity",
  "Object",
  "Array",
  "String",
  "Number",
  "Boolean",
  "class",
  "function",
  "return",
  "const",
  "let",
  "var",
  "new",
  "instance",
  "subject",
]);

const MAX_FALLBACK_CASES = 2;

function sanitizeIdentifier(raw, fallback = "value") {
  let name = String(raw || fallback).replace(/[^a-zA-Z0-9_$]/g, "");

  if (!name || /^[0-9]/.test(name)) {
    name = fallback;
  }

  if (RESERVED_NAMES.has(name)) {
    name = `${name}Arg`;
  }

  return name;
}

function uniqueParamNames(params = [], prefix = "arg") {
  const used = new Set();
  const out = [];

  for (let i = 0; i < (params || []).length; i++) {
    const raw = typeof params[i] === "string" ? params[i] : params[i]?.name;
    const base = sanitizeIdentifier(raw, `${prefix}${i + 1}`);

    let candidate = base;
    let counter = 2;

    while (used.has(candidate) || RESERVED_NAMES.has(candidate)) {
      candidate = `${base}${counter}`;
      counter++;
    }

    used.add(candidate);
    out.push(candidate);
  }

  return out;
}

function lowerName(value) {
  return String(value || "").toLowerCase();
}

function normalizeCode(functionCode = "") {
  return String(functionCode || "")
    .replace(/\r\n/g, "\n")
    .trim();
}

/**
 * Source-shape inference.
 *
 * This does not try to prove exact behavior.
 * It only detects safe broad signals so fallback assertions can be more useful.
 */
export function analyzeFunctionReturnShape(functionCode = "", fnName = "") {
  const code = normalizeCode(functionCode);
  const lower = code.toLowerCase();
  const nameLower = lowerName(fnName);

  const shape = {
    hasFunctionCode: Boolean(code),

    // Return-shape hints
    returnsArrayLiteral: /\breturn\s+\[/.test(code),
    returnsObjectLiteral: /\breturn\s+\{/.test(code),
    returnsNull: /\breturn\s+null\b/.test(code),
    returnsUndefined: /\breturn\s+undefined\b/.test(code),
    returnsBooleanLiteral: /\breturn\s+(true|false)\b/.test(code),
    returnsNumericLiteral: /\breturn\s+-?\d+(\.\d+)?\b/.test(code),
    returnsStringLiteral: /\breturn\s+["'`]/.test(code),
    returnsThis: /\breturn\s+this\s*(?:;|\n|\}|$)/.test(code),
    returnsNewInstance: /\breturn\s+new\s+[A-Z][A-Za-z0-9_$]*\s*\(/.test(code),
    returnsPromise: /\bPromise\./.test(code) || /\basync\b/.test(code),

    // Collection/object operation hints
    usesObjectKeys: /\bObject\.keys\s*\(/.test(code),
    usesObjectValues: /\bObject\.values\s*\(/.test(code),
    usesObjectEntries: /\bObject\.entries\s*\(/.test(code),
    usesArrayIsArray: /\bArray\.isArray\s*\(/.test(code),
    usesMap: /\.map\s*\(/.test(code),
    usesFilter: /\.filter\s*\(/.test(code),
    usesFind: /\.find\s*\(/.test(code),
    usesReduce: /\.reduce\s*\(/.test(code),
    usesIncludes: /\.includes\s*\(/.test(code),
    usesLength: /\.length\b/.test(code),

    // Lookup/defaulting hints
    usesNullFallback: /\|\|\s*null\b/.test(code) || /\?\?\s*null\b/.test(code),
    usesUndefinedFallback:
      /\|\|\s*undefined\b/.test(code) || /\?\?\s*undefined\b/.test(code),
    usesBracketLookup: /\[[A-Za-z_$][A-Za-z0-9_$]*\]/.test(code),
    usesPropertyAccess: /\.[A-Za-z_$][A-Za-z0-9_$]*\b/.test(code),

    // Class/object method hints
    usesThis: /\bthis\./.test(code),
    mutatesThis: /\bthis\.[A-Za-z_$][A-Za-z0-9_$]*\s*=/.test(code),

    // IO / risky hints
    usesFs: /\bfs\./.test(code) || /\breadFile|writeFile|existsSync/.test(code),
    usesFetch: /\bfetch\s*\(/.test(code),
    usesAxios: /\baxios\./.test(code),
    usesProcessEnv: /\bprocess\.env\b/.test(code),

    // Name hints
    nameLooksCollection:
      nameLower.includes("all") ||
      nameLower.includes("list") ||
      nameLower.includes("many") ||
      nameLower.includes("array") ||
      nameLower.includes("items") ||
      nameLower.includes("countries") ||
      nameLower.includes("timezones") ||
      nameLower.startsWith("getall") ||
      nameLower.startsWith("findall"),

    nameLooksLookup:
      nameLower.startsWith("get") ||
      nameLower.startsWith("find") ||
      nameLower.startsWith("lookup") ||
      nameLower.startsWith("search") ||
      nameLower.includes("byid") ||
      nameLower.includes("for"),

    nameLooksBoolean:
      nameLower.startsWith("is") ||
      nameLower.startsWith("has") ||
      nameLower.startsWith("can") ||
      nameLower.startsWith("should") ||
      nameLower.includes("exists") ||
      nameLower.includes("valid"),

    nameLooksNumeric:
      nameLower.includes("count") ||
      nameLower.includes("sum") ||
      nameLower.includes("total") ||
      nameLower.includes("average") ||
      nameLower.includes("mean") ||
      nameLower.includes("median") ||
      nameLower.includes("variance") ||
      nameLower.includes("distance") ||
      nameLower.includes("size") ||
      nameLower.includes("length") ||
      nameLower.includes("abs") ||
      nameLower.includes("magnitude") ||
      nameLower.includes("angle") ||
      nameLower.includes("bearing") ||
      nameLower.includes("radius"),

    nameLooksString:
      nameLower.includes("string") ||
      nameLower.includes("format") ||
      nameLower.includes("label") ||
      nameLower.includes("name") ||
      nameLower.includes("text"),
  };

  shape.likelyArray =
    shape.returnsArrayLiteral ||
    shape.usesObjectValues ||
    shape.usesObjectEntries ||
    shape.usesMap ||
    shape.usesFilter ||
    shape.nameLooksCollection;

  shape.likelyObject =
    shape.returnsObjectLiteral ||
    shape.returnsThis ||
    shape.returnsNewInstance ||
    shape.usesObjectKeys ||
    shape.usesBracketLookup ||
    shape.nameLooksLookup;

  shape.likelyNullable =
    shape.returnsNull ||
    shape.returnsUndefined ||
    shape.usesNullFallback ||
    shape.usesUndefinedFallback;

  shape.likelyBoolean = shape.returnsBooleanLiteral || shape.nameLooksBoolean;
  shape.likelyNumber = shape.returnsNumericLiteral || shape.nameLooksNumeric;
  shape.likelyString = shape.returnsStringLiteral || shape.nameLooksString;

  shape.usesCollectionOperation =
    shape.usesObjectKeys ||
    shape.usesObjectValues ||
    shape.usesObjectEntries ||
    shape.usesArrayIsArray ||
    shape.usesMap ||
    shape.usesFilter ||
    shape.usesFind ||
    shape.usesReduce ||
    shape.usesIncludes ||
    shape.usesLength;

  shape.hasRiskyExternalBehavior =
    shape.usesFs ||
    shape.usesFetch ||
    shape.usesAxios ||
    shape.usesProcessEnv;

  return shape;
}

function looksArrayLikeParam(paramName) {
  const lower = lowerName(paramName);

  return (
    lower === "arr" ||
    lower === "array" ||
    lower === "list" ||
    lower === "items" ||
    lower === "values" ||
    lower === "data" ||
    lower.endsWith("arr") ||
    lower.endsWith("array") ||
    lower.endsWith("list") ||
    lower.endsWith("items") ||
    lower.endsWith("values") ||
    lower.includes("array") ||
    lower.includes("list") ||
    lower.includes("items") ||
    lower.includes("values")
  );
}

function paramUsedWithArrayLikeApi(paramName, functionCode = "") {
  const code = normalizeCode(functionCode);
  const safeParam = String(paramName || "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

  if (!safeParam) return false;

  return new RegExp(
    `\\b${safeParam}\\s*\\.\\s*(?:indexOf|includes|push|pop|shift|unshift|slice|splice|map|filter|some|every|reduce|forEach)\\s*\\(`,
    "m"
  ).test(code);
}

function looksTrackingArrayParam(paramName) {
  const lower = lowerName(paramName);

  return (
    lower === "known" ||
    lower === "seen" ||
    lower === "visited" ||
    lower === "cache" ||
    lower === "stack" ||
    lower.endsWith("list") ||
    lower.endsWith("set") ||
    lower.includes("known") ||
    lower.includes("seen") ||
    lower.includes("visited")
  );
}

function looksObjectLikeParam(paramName) {
  const lower = lowerName(paramName);

  return (
    lower === "obj" ||
    lower === "object" ||
    lower === "payload" ||
    lower.endsWith("obj") ||
    lower.endsWith("object") ||
    lower.endsWith("payload")
  );
}

function looksOptionsLikeParam(paramName) {
  const lower = lowerName(paramName);

  return (
    lower === "options" ||
    lower === "opts" ||
    lower === "config" ||
    lower === "settings" ||
    lower.endsWith("options") ||
    lower.endsWith("opts") ||
    lower.endsWith("config") ||
    lower.endsWith("settings")
  );
}

function looksBooleanLikeParam(paramName) {
  const lower = lowerName(paramName);

  return (
    lower.startsWith("is") ||
    lower.startsWith("has") ||
    lower.startsWith("can") ||
    lower.startsWith("should") ||
    lower.includes("enabled") ||
    lower.includes("disabled") ||
    lower.includes("flag")
  );
}

function looksFunctionLikeParam(paramName) {
  const lower = lowerName(paramName);

  return (
    lower === "fn" ||
    lower === "cb" ||
    lower === "callback" ||
    lower === "handler" ||
    lower === "updater" ||
    lower === "transformer" ||
    lower === "transform" ||
    lower === "predicate" ||
    lower === "comparator" ||
    lower === "mapper" ||
    lower === "reducer" ||
    lower === "func" ||
    lower.includes("callback") ||
    lower.includes("handler") ||
    lower.includes("updater") ||
    lower.includes("transform") ||
    lower.endsWith("fn") ||
    lower.endsWith("cb") ||
    lower.includes("randomsource") ||
    lower.includes("kernel") ||
    lower.includes("bandwidthmethod")
  );
}

function looksStringLikeParam(paramName) {
  const lower = lowerName(paramName);

  return (
    lower.includes("name") ||
    lower.includes("text") ||
    lower.includes("message") ||
    lower.includes("title") ||
    lower.includes("label") ||
    lower.includes("key") ||
    lower.includes("type") ||
    lower.includes("id") ||
    lower.includes("code") ||
    lower.includes("country") ||
    lower.includes("timezone") ||
    lower.includes("path") ||
    lower.includes("file") ||
    lower.includes("url") ||
    lower.includes("email") ||
    lower.includes("token") ||
    lower === "str" ||
    lower === "string"
  );
}

function looksNumberLikeParam(paramName) {
  const lower = lowerName(paramName);

  return (
    lower === "n" ||
    lower === "x" ||
    lower === "y" ||
    lower === "z" ||
    lower === "i" ||
    lower === "j" ||
    lower === "k" ||
    lower.includes("lat") ||
    lower.includes("lon") ||
    lower.includes("lng") ||
    lower.includes("long") ||
    lower.includes("radius") ||
    lower.includes("angle") ||
    lower.includes("degree") ||
    lower.includes("radian") ||
    lower.includes("count") ||
    lower.includes("size") ||
    lower.includes("length") ||
    lower.includes("index") ||
    lower.includes("limit") ||
    lower.includes("offset") ||
    lower.includes("start") ||
    lower.includes("end") ||
    lower.includes("left") ||
    lower.includes("right") ||
    lower.includes("num") ||
    lower.includes("number") ||
    lower.includes("age") ||
    lower.includes("total") ||
    lower.includes("amount") ||
    lower.includes("real") ||
    lower.includes("imag")
  );
}

function buildFunctionLiteral(paramName) {
  const lower = lowerName(paramName);

  if (lower.includes("comparator")) {
    return "(a, b) => a - b";
  }

  if (lower.includes("predicate")) {
    return "(x) => Boolean(x)";
  }

  if (lower.includes("mapper")) {
    return "(x) => x";
  }

  if (lower.includes("reducer")) {
    return "(acc, x) => acc + x";
  }

  if (lower.includes("randomsource")) {
    return "() => 0.5";
  }

  if (lower.includes("kernel")) {
    return "(x) => x";
  }

  if (lower.includes("bandwidthmethod")) {
    return "() => 1";
  }

  return "() => 0";
}

function extractComparedStringLiterals(functionCode = "", paramName = "") {
  const code = normalizeCode(functionCode);
  const safeParam = String(paramName || "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

  if (!safeParam) return [];

  const patterns = [
    new RegExp(`${safeParam}\\s*={2,3}\\s*["'\`]([^"'\`]{1,80})["'\`]`, "g"),
    new RegExp(`["'\`]([^"'\`]{1,80})["'\`]\\s*={2,3}\\s*${safeParam}`, "g"),
    new RegExp(`${safeParam}\\s*!={1,2}\\s*["'\`]([^"'\`]{1,80})["'\`]`, "g"),
  ];

  const values = [];

  for (const pattern of patterns) {
    let match;
    while ((match = pattern.exec(code))) {
      if (match[1]) values.push(match[1]);
    }
  }

  return Array.from(new Set(values)).slice(0, 3);
}

function extractFirstUsefulStringLiteral(functionCode = "") {
  const code = normalizeCode(functionCode);
  const values = [];

  const re = /["'`]([^"'`\n]{1,80})["'`]/g;
  let match;

  while ((match = re.exec(code))) {
    const value = match[1];

    if (!value) continue;
    if (value.includes("__")) continue;
    if (value.includes("\\")) continue;
    if (/^[{}[\](),.;:]$/.test(value)) continue;
    if (/^(use strict|module|default|exports)$/.test(value.toLowerCase())) continue;

    values.push(value);
  }

  return values[0] || "sample";
}

function extractOptionObjectKeys(functionCode = "") {
  const code = normalizeCode(functionCode);
  const keys = [];
  const add = (key) => {
    if (!key || key.startsWith("_")) return;
    if (!/^[A-Za-z_$][A-Za-z0-9_$]*$/.test(key)) return;
    if (!["url", "dest", "filename", "path", "timeout", "extractFilename", "headers", "method", "encoding"].includes(key)) {
      return;
    }
    if (!keys.includes(key)) keys.push(key);
  };

  const objectPatternRe = /\(\s*\{([^)]{1,300})\}\s*(?:=\s*\{\})?\s*\)/g;
  let objectMatch;
  while ((objectMatch = objectPatternRe.exec(code))) {
    const body = objectMatch[1] || "";
    for (const part of body.split(",")) {
      const cleaned = part
        .trim()
        .replace(/^\.\.\./, "")
        .replace(/=.*/, "")
        .replace(/:.*/, "")
        .trim();
      add(cleaned);
    }
  }

  const optionsPropRe = /\b(?:options|opts|config|settings)\.([A-Za-z_$][A-Za-z0-9_$]*)/g;
  let propMatch;
  while ((propMatch = optionsPropRe.exec(code))) {
    add(propMatch[1]);
  }

  return keys;
}

function buildOptionsObjectLiteral(functionCode = "", variant = "primary") {
  const keys = extractOptionObjectKeys(functionCode);
  if (keys.length === 0) return "{}";

  const fields = [];
  const addField = (key, value) => {
    if (!fields.some((field) => field.startsWith(`${key}:`))) {
      fields.push(`${key}: ${value}`);
    }
  };

  for (const key of keys) {
    const lower = lowerName(key);
    if (lower === "url") {
      addField(key, variant === "secondary" ? '"https://example.com/unitgen.png"' : '"http://example.com/unitgen.png"');
    } else if (lower === "dest" || lower === "filename" || lower === "path") {
      addField(key, variant === "secondary" ? '"./unitgen-output.png"' : '"./unitgen-output"');
    } else if (lower === "timeout") {
      addField(key, variant === "secondary" ? "1" : "1000");
    } else if (lower === "extractfilename") {
      addField(key, variant === "secondary" ? "false" : "true");
    } else if (lower === "headers") {
      addField(key, "{}");
    } else if (lower === "method") {
      addField(key, '"GET"');
    } else if (lower === "encoding") {
      addField(key, '"utf8"');
    }
  }

  return fields.length > 0 ? `{ ${fields.join(", ")} }` : "{}";
}
function buildBetterDefaultValueForParam(
  paramName,
  index = 0,
  functionCode = "",
  variant = "primary"
) {
  const lower = lowerName(paramName);
  const comparedStrings = extractComparedStringLiterals(functionCode, paramName);
  const secondary = variant === "secondary";

  if (looksFunctionLikeParam(paramName)) {
    if (secondary) return "() => 1";
    return buildFunctionLiteral(paramName);
  }

  if (looksOptionsLikeParam(paramName)) {
    return buildOptionsObjectLiteral(functionCode, variant);
  }

  if (looksDirectoryPathLikeParam(paramName)) {
    return `"."`;
  }

  if (looksFilePathLikeParam(paramName)) {
    return `"./unitgen-temp.json"`;
  }

  if (lower === "type") {
    return `"file"`;
  }

  if (lower === "combine") {
    return "false";
  }

  if (looksObjectLikeParam(paramName)) {
    return secondary ? `{ sample: "value" }` : "{}";
  }

  if (
    looksArrayLikeParam(paramName) ||
    looksTrackingArrayParam(paramName) ||
    paramUsedWithArrayLikeApi(paramName, functionCode)
  ) {
    return secondary ? "[]" : "[1, 2, 3]";
  }

  if (looksBooleanLikeParam(paramName)) {
    return secondary ? "false" : "true";
  }

  if (looksStringLikeParam(paramName)) {
    if (comparedStrings.length > 0) {
      return JSON.stringify(comparedStrings[0]);
    }

    if (
      lower.includes("timezone") ||
      lower.includes("country") ||
      lower.includes("code") ||
      lower.includes("id") ||
      lower.includes("key") ||
      lower.includes("type")
    ) {
      return JSON.stringify(extractFirstUsefulStringLiteral(functionCode));
    }

    return secondary ? `""` : `"sample"`;
  }

  if (looksNumberLikeParam(paramName)) {
    return secondary ? "0" : index === 1 ? "2" : "1";
  }

  return secondary ? "0" : index === 1 ? "2" : "1";
}

function buildDefaultArrange(
  params = [],
  functionCode = "",
  prefix = "arg",
  variant = "primary"
) {
  const names = uniqueParamNames(params, prefix);
  const lines = [];

  for (let i = 0; i < names.length; i++) {
    const name = names[i];
    const value = buildBetterDefaultValueForParam(name, i, functionCode, variant);
    lines.push(`const ${name} = ${value};`);
  }

  return {
    arrange: lines.join("\n"),
    argNames: names,
  };
}

function buildFileApiArrange(params = [], mode = "read") {
  const argNames = uniqueParamNames(params, "arg");
  const lines = [];

  const hasDirectoryParam = argNames.some((name) => looksDirectoryPathLikeParam(name));

  if (hasDirectoryParam) {
    lines.push(`const __unitgenDirPath = fs.mkdtempSync(path.join(os.tmpdir(), "unitgen-"));`);
    lines.push(`fs.writeFileSync(path.join(__unitgenDirPath, "sample.txt"), "sample", "utf8");`);
  }

  lines.push(
    mode === "read"
      ? `const __unitgenFilePath = "./unitgen-temp.json";`
      : `const __unitgenFilePath = "./unitgen-temp-output.json";`
  );

  if (mode === "read") {
    lines.push(`fs.writeFileSync(__unitgenFilePath, '{"name":"unitgen","ok":true}', "utf8");`);
  }

  for (let i = 0; i < argNames.length; i++) {
    const name = argNames[i];
    const lower = lowerName(name);

    if (looksDirectoryPathLikeParam(lower)) {
      lines.push(`const ${name} = __unitgenDirPath;`);
    } else if (looksFilePathLikeParam(lower)) {
      lines.push(`const ${name} = __unitgenFilePath;`);
    } else if (lower === "type") {
      lines.push(`const ${name} = "file";`);
    } else if (lower === "combine") {
      lines.push(`const ${name} = false;`);
    } else if (
      lower === "options" ||
      lower === "opts" ||
      lower.endsWith("options") ||
      lower.endsWith("opts")
    ) {
      lines.push(
        mode === "read"
          ? `const ${name} = { encoding: "utf8" };`
          : `const ${name} = {};`
      );
    } else if (
      lower.includes("obj") ||
      lower.includes("json") ||
      lower.includes("data") ||
      lower.includes("content") ||
      lower.includes("value")
    ) {
      lines.push(`const ${name} = { name: "unitgen", ok: true };`);
    } else {
      lines.push(`const ${name} = ${buildBetterDefaultValueForParam(name, i, "")};`);
    }
  }

  return {
    arrange: lines.join("\n"),
    argNames,
  };
}

function getParamName(param) {
  return typeof param === "string" ? param : param?.name;
}

function looksFilePathLikeParam(paramName = "") {
  const lower = lowerName(paramName);

  return (
    lower.includes("file") ||
    lower.includes("path") ||
    lower.includes("filename")
  );
}

function looksDirectoryPathLikeParam(paramName = "") {
  const lower = lowerName(paramName);

  return (
    lower === "dir" ||
    lower === "directory" ||
    lower === "folder" ||
    lower === "root" ||
    lower === "cwd" ||
    lower.endsWith("dir") ||
    lower.endsWith("directory") ||
    lower.endsWith("folder") ||
    lower.includes("dirname")
  );
}

function isFileReadApi(fnName = "", params = []) {
  const name = lowerName(fnName);

  if (!name.includes("read")) return false;

  return (params || []).some((p) => {
    const paramName = getParamName(p);
    return looksFilePathLikeParam(paramName) || looksDirectoryPathLikeParam(paramName);
  });
}

function isFileWriteApi(fnName = "", params = []) {
  const name = lowerName(fnName);

  if (!name.includes("write")) return false;

  return (params || []).some((p) => looksFilePathLikeParam(getParamName(p)));
}

function isDirectoryTraversalApi(fnName = "", params = []) {
  const name = lowerName(fnName);
  const hasDirectoryParam = (params || []).some((p) =>
    looksDirectoryPathLikeParam(getParamName(p))
  );

  if (!hasDirectoryParam) return false;

  return (
    name.includes("file") ||
    name.includes("path") ||
    name.includes("dir") ||
    name.includes("subdir")
  );
}

function patchFilePathArrange(
  arrange = "",
  argNames = [],
  filePathConstName = "__unitgenFilePath",
  { mode = "read" } = {}
) {
  let patched = String(arrange || "");

  for (const argName of argNames || []) {
    const safeName = sanitizeIdentifier(argName, "arg");
    const lower = lowerName(safeName);

    if (looksFilePathLikeParam(lower)) {
      patched = patched.replace(
        new RegExp(`const\\s+${safeName}\\s*=\\s*[^;]+;`),
        `const ${safeName} = ${filePathConstName};`
      );
    }

    if (
      lower === "options" ||
      lower === "opts" ||
      lower.endsWith("options") ||
      lower.endsWith("opts")
    ) {
      patched = patched.replace(
        new RegExp(`const\\s+${safeName}\\s*=\\s*[^;]+;`),
        mode === "read"
          ? `const ${safeName} = { encoding: "utf8" };`
          : `const ${safeName} = {};`
      );
    }
  }

  return patched;
}

function buildFileReadFallbackAssertion() {
  return [
    `expect(result).toBeDefined();`,
    `expect(typeof result === "object" || typeof result === "string").toBe(true);`,
  ].join("\n");
}

function buildFileWriteFallbackAssertion() {
  return `expect(result === undefined || result !== undefined).toBe(true);`;
}

function buildDirectoryTraversalFallbackAssertion(variant = "primary") {
  if (variant === "secondary") {
    return `expect(result == null || result.name !== "Error").toBe(true);`;
  }

  return `expect(result == null || Array.isArray(result) || typeof result === "object" || typeof result === "string").toBe(true);`;
}

function functionLooksVoidOrMutating(fnName = "", functionCode = "") {
  const name = lowerName(fnName);
  const code = normalizeCode(functionCode);
  const hasReturn = /\breturn\b/.test(code);

  return (
    (!hasReturn && Boolean(code)) ||
    /^(set|add|put|insert|save|write|append|push|pop|shift|unshift|remove|rm|delete|del|clear|update|close|destroy|end|emit|forEach)$/.test(name) ||
    name.startsWith("set") ||
    name.startsWith("add") ||
    name.startsWith("remove") ||
    name.startsWith("delete") ||
    name.startsWith("update") ||
    name.startsWith("close") ||
    name.startsWith("write")
  );
}

function buildCallExpression(fnName, argNames = [], isClassLike = false) {
  const safeFnName = sanitizeIdentifier(fnName, "subject");
  const args = argNames.join(", ");

  if (isClassLike) {
    return `new ${safeFnName}(${args})`;
  }

  return `${safeFnName}(${args})`;
}

function extractDirectGuardFallbackCase({
  fnName,
  params = [],
  functionCode = "",
  isClassLike = false,
}) {
  if (isClassLike || !fnName || !Array.isArray(params) || params.length === 0) {
    return null;
  }

  const code = normalizeCode(functionCode);
  const firstParam = getParamName(params[0]);
  const safeParam = String(firstParam || "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

  if (!code || !safeParam) return null;

  const literalToken =
    "(?:null|undefined|NaN|Infinity|-Infinity|true|false|-?\\d+(?:\\.\\d+)?|[\"'`][^\"'`\\n]{0,80}[\"'`])";
  const guardPattern = new RegExp(
    `if\\s*\\(\\s*${safeParam}\\s*={2,3}\\s*(${literalToken})\\s*\\)\\s*(?:\\{\\s*)?return\\s+(${literalToken})\\s*;?`,
    "m"
  );
  const match = guardPattern.exec(code);

  if (!match) return null;

  const inputLiteral = match[1];
  const expectedLiteral = match[2];
  const argNames = uniqueParamNames(params, "arg");
  const arrangeLines = [];

  for (let i = 0; i < argNames.length; i++) {
    const value =
      i === 0
        ? inputLiteral
        : buildBetterDefaultValueForParam(
            argNames[i],
            i,
            functionCode,
            "secondary"
          );
    arrangeLines.push(`const ${argNames[i]} = ${value};`);
  }

  return {
    title: normalizeTitle(
      `fallback follows source guard for ${String(firstParam || "input")}`
    ),
    arrange: arrangeLines.join("\n"),
    act: buildCallExpression(fnName, argNames, false),
    assert: `expect(result).toBe(${expectedLiteral});`,
    source: "fallback",
  };
}
function functionLooksCollectionReturning(fnName = "") {
  const lower = lowerName(fnName);

  return (
    lower.includes("all") ||
    lower.includes("list") ||
    lower.includes("many") ||
    lower.includes("array") ||
    lower.includes("items") ||
    lower.includes("countries") ||
    lower.includes("timezones") ||
    lower.startsWith("getall") ||
    lower.startsWith("findall")
  );
}

function functionLooksLookup(fnName = "") {
  const lower = lowerName(fnName);

  return (
    lower.startsWith("get") ||
    lower.startsWith("find") ||
    lower.startsWith("lookup") ||
    lower.startsWith("search") ||
    lower.includes("byid") ||
    lower.includes("for")
  );
}

function functionLooksBooleanReturning(fnName = "") {
  const lower = lowerName(fnName);

  return (
    lower.startsWith("is") ||
    lower.startsWith("has") ||
    lower.startsWith("can") ||
    lower.startsWith("should") ||
    lower.includes("exists") ||
    lower.includes("valid") ||
    lower.includes("equal")
  );
}

function functionLooksNumericReturning(fnName = "") {
  const lower = lowerName(fnName);

  return (
    lower.includes("count") ||
    lower.includes("sum") ||
    lower.includes("total") ||
    lower.includes("average") ||
    lower.includes("mean") ||
    lower.includes("median") ||
    lower.includes("variance") ||
    lower.includes("distance") ||
    lower.includes("size") ||
    lower.includes("length") ||
    lower.includes("abs") ||
    lower.includes("magnitude") ||
    lower.includes("angle") ||
    lower.includes("bearing") ||
    lower.includes("radius")
  );
}

/**
 * Builds a stronger but still safe assertion based on function source.
 *
 * This returns assertions that are:
 * - result-centered
 * - sanitizer-compatible
 * - runtime-validation friendly
 * - not based on fabricated exact domain outputs
 */
function buildSourceAwareAssertion(fnName = "", functionCode = "", variant = "primary") {
  const shape = analyzeFunctionReturnShape(functionCode, fnName);

  if (functionLooksVoidOrMutating(fnName, functionCode)) {
    return buildFileWriteFallbackAssertion();
  }

  if (shape.likelyBoolean) {
    return `expect(result == null || typeof result === "boolean").toBe(true);`;
  }

  if (shape.likelyNumber) {
    return `expect(result == null || typeof result === "number").toBe(true);`;
  }

  if (shape.likelyString) {
    return `expect(result == null || typeof result === "string").toBe(true);`;
  }

  if (shape.returnsThis || shape.returnsNewInstance) {
    return `expect(result).toBeDefined();`;
  }

  if (shape.usesObjectValues || shape.usesObjectEntries || shape.returnsArrayLiteral) {
    if (variant === "secondary") {
      return `expect(result == null || Array.isArray(result)).toBe(true);`;
    }

    return [
      `expect(result == null || Array.isArray(result)).toBe(true);`,
      `expect(result == null || result.length >= 0).toBe(true);`,
    ].join("\n");
  }

  if (shape.usesMap || shape.usesFilter || shape.nameLooksCollection) {
    if (variant === "secondary") {
      return `expect(result == null || Array.isArray(result) || typeof result === "object").toBe(true);`;
    }

    return [
      `expect(result).toBeDefined();`,
      `expect(Array.isArray(result) || typeof result === "object").toBe(true);`,
    ].join("\n");
  }

  if (shape.usesObjectKeys || shape.returnsObjectLiteral) {
    if (variant === "secondary") {
      return `expect(result == null || typeof result === "object").toBe(true);`;
    }

    return [
      `expect(result).toBeDefined();`,
      `expect(typeof result).toBe("object");`,
    ].join("\n");
  }

  if (shape.usesFind || shape.usesBracketLookup || shape.nameLooksLookup) {
    if (variant === "secondary") {
      return `expect(result == null || typeof result === "object" || typeof result === "string" || typeof result === "number" || typeof result === "boolean").toBe(true);`;
    }

    return `expect(result == null || typeof result === "object").toBe(true);`;
  }

  if (functionLooksBooleanReturning(fnName)) {
    return `expect(result == null || typeof result === "boolean").toBe(true);`;
  }

  if (functionLooksNumericReturning(fnName)) {
    return `expect(result == null || typeof result === "number").toBe(true);`;
  }

  if (functionLooksCollectionReturning(fnName)) {
    return `expect(result == null || Array.isArray(result) || typeof result === "object").toBe(true);`;
  }

  if (functionLooksLookup(fnName)) {
    return `expect(result == null || typeof result === "object" || typeof result === "string" || typeof result === "number" || typeof result === "boolean").toBe(true);`;
  }

  if (variant === "secondary") {
    return `expect(result == null || result !== undefined).toBe(true);`;
  }

  return `expect(result).toBeDefined();`;
}

function buildNoThrowAssertion(fnName = "", functionCode = "") {
  const shape = analyzeFunctionReturnShape(functionCode, fnName);

  if (functionLooksVoidOrMutating(fnName, functionCode)) {
    return buildFileWriteFallbackAssertion();
  }

  if (shape.likelyBoolean) {
    return `expect(result == null || typeof result === "boolean").toBe(true);`;
  }

  if (shape.likelyNumber) {
    return `expect(result == null || typeof result === "number").toBe(true);`;
  }

  if (shape.likelyString) {
    return `expect(result == null || typeof result === "string").toBe(true);`;
  }

  if (shape.likelyArray) {
    return `expect(result == null || Array.isArray(result) || typeof result === "object").toBe(true);`;
  }

  if (shape.likelyObject || functionLooksLookup(fnName)) {
    return `expect(result == null || typeof result === "object").toBe(true);`;
  }

  return `expect(result == null || result !== undefined).toBe(true);`;
}

function normalizeTitle(title) {
  return String(title || "fallback generated test")
    .replace(/\s+/g, " ")
    .replace(/"/g, '\\"')
    .trim();
}
function buildFallbackCase({
  title,
  fnName,
  params = [],
  isClassLike = false,
  assertion,
  functionCode = "",
  arrangeVariant = "primary",
}) {
  const readApi = isFileReadApi(fnName, params);
  const writeApi = isFileWriteApi(fnName, params);
  const directoryTraversalApi = isDirectoryTraversalApi(fnName, params);

  let arrangeData;

  if (readApi || directoryTraversalApi) {
    arrangeData = buildFileApiArrange(params, "read");
  } else if (writeApi) {
    arrangeData = buildFileApiArrange(params, "write");
  } else {
    arrangeData = buildDefaultArrange(params, functionCode, "arg", arrangeVariant);
  }

  const { arrange, argNames } = arrangeData;
  const act = buildCallExpression(fnName, argNames, isClassLike);

  const finalAssertion = directoryTraversalApi
    ? buildDirectoryTraversalFallbackAssertion(arrangeVariant)
    : readApi
    ? buildFileReadFallbackAssertion()
    : writeApi
      ? buildFileWriteFallbackAssertion()
      : assertion || buildSourceAwareAssertion(fnName, functionCode);

  return {
    title: normalizeTitle(title),
    arrange,
    act,
    assert: finalAssertion,
    source: "fallback",
  };
}

function buildNoParamFallbackCases({ fnName, functionCode, maxCases }) {
  const cases = [];

  cases.push({
    title: normalizeTitle("fallback checks source-aware result shape"),
    arrange: "",
    act: `${sanitizeIdentifier(fnName, "subject")}()`,
    assert: buildSourceAwareAssertion(fnName, functionCode, "primary"),
    source: "fallback",
  });

  cases.push({
    title: normalizeTitle("fallback checks stable result contract"),
    arrange: "",
    act: `${sanitizeIdentifier(fnName, "subject")}()`,
    assert: buildSourceAwareAssertion(fnName, functionCode, "secondary"),
    source: "fallback",
  });

  return cases.slice(0, maxCases);
}

function buildParamFallbackCases({
  fnName,
  params,
  isClassLike,
  functionCode,
  isAsync,
  maxCases,
}) {
  const cases = [];
  const directGuardCase = extractDirectGuardFallbackCase({
    fnName,
    params,
    functionCode,
    isClassLike,
  });

  if (directGuardCase) cases.push(directGuardCase);

  cases.push(
    buildFallbackCase({
      title: directGuardCase
        ? "fallback checks stable result contract"
        : isAsync
          ? "fallback checks source-aware result shape asynchronously"
          : "fallback checks source-aware result shape",
      fnName,
      params,
      isClassLike,
      functionCode,
      assertion: directGuardCase
        ? buildNoThrowAssertion(fnName, functionCode)
        : buildSourceAwareAssertion(fnName, functionCode, "primary"),
      arrangeVariant: directGuardCase ? "secondary" : "primary",
    })
  );

  if (!directGuardCase) {
    cases.push(
      buildFallbackCase({
        title: "fallback checks stable result contract",
        fnName,
        params,
        isClassLike,
        functionCode,
        assertion: buildNoThrowAssertion(fnName, functionCode),
        arrangeVariant: "secondary",
      })
    );
  }

  return cases.slice(0, maxCases);
}

function buildConstructorFallbackCases({
  ownerClassName,
  constructorParams = [],
  constructorCode = "",
  maxCases,
}) {
  const className = sanitizeIdentifier(ownerClassName, "SubjectClass");
  const { arrange, argNames } = buildDefaultArrange(
    constructorParams,
    constructorCode,
    "ctorArg"
  );

  const args = argNames.join(", ");
  const cases = [];

  cases.push({
    title: normalizeTitle(`${className} constructor creates an instance`),
    arrange,
    act: `new ${className}(${args})`,
    assert: [
      `expect(result).toBeDefined();`,
      `expect(typeof result === "object" || typeof result === "function").toBe(true);`,
    ].join("\n"),
    source: "fallback",
  });

  cases.push({
    title: normalizeTitle(`${className} constructor exposes an object-like result`),
    arrange,
    act: `new ${className}(${args})`,
    assert: `expect(result == null || typeof result === "object" || typeof result === "function").toBe(true);`,
    source: "fallback",
  });

  return cases.slice(0, maxCases);
}

function buildClassMethodArrange({
  ownerClassName,
  constructorParams = [],
  constructorCode = "",
  methodParams = [],
  methodCode = "",
}) {
  const className = sanitizeIdentifier(ownerClassName, "SubjectClass");

  const ctor = buildDefaultArrange(constructorParams, constructorCode, "ctorArg");
  const method = buildDefaultArrange(methodParams, methodCode, "methodArg");

  const lines = [];

  if (ctor.arrange) lines.push(ctor.arrange);
  lines.push(`const instance = new ${className}(${ctor.argNames.join(", ")});`);
  if (method.arrange) lines.push(method.arrange);

  return {
    arrange: lines.join("\n"),
    methodArgNames: method.argNames,
  };
}

function buildStaticMethodArrange({
  methodParams = [],
  methodCode = "",
}) {
  return buildDefaultArrange(methodParams, methodCode, "methodArg");
}

function buildClassMethodAssertion({
  methodName,
  methodCode = "",
  methodKind = "prototype",
  variant = "primary",
}) {
  if (methodKind === "constructor") {
    return [
      `expect(result).toBeDefined();`,
      `expect(typeof result === "object" || typeof result === "function").toBe(true);`,
    ].join("\n");
  }

  return buildSourceAwareAssertion(methodName, methodCode, variant);
}

function buildClassMethodFallbackCases({
  ownerClassName,
  methodName,
  methodKind = "prototype",
  constructorParams = [],
  constructorCode = "",
  params = [],
  functionCode = "",
  isAsync = false,
  maxCases,
}) {
  const className = sanitizeIdentifier(ownerClassName, "SubjectClass");
  const safeMethodName = sanitizeIdentifier(methodName, "method");

  if (methodKind === "constructor") {
    return buildConstructorFallbackCases({
      ownerClassName: className,
      constructorParams,
      constructorCode: constructorCode || functionCode,
      maxCases,
    });
  }

  const cases = [];

  if (methodKind === "static") {
    const { arrange, argNames } = buildStaticMethodArrange({
      methodParams: params,
      methodCode: functionCode,
    });

    cases.push({
      title: normalizeTitle(`${className}.${safeMethodName} checks source-aware result shape`),
      arrange,
      act: `${className}.${safeMethodName}(${argNames.join(", ")})`,
      assert: buildClassMethodAssertion({
        methodName: safeMethodName,
        methodCode: functionCode,
        methodKind,
        variant: "primary",
      }),
      source: "fallback",
    });

    cases.push({
      title: normalizeTitle(`${className}.${safeMethodName} checks stable result contract`),
      arrange,
      act: `${className}.${safeMethodName}(${argNames.join(", ")})`,
      assert: buildClassMethodAssertion({
        methodName: safeMethodName,
        methodCode: functionCode,
        methodKind,
        variant: "secondary",
      }),
      source: "fallback",
    });

    return cases.slice(0, maxCases);
  }

  const methodArrange = buildClassMethodArrange({
    ownerClassName: className,
    constructorParams,
    constructorCode,
    methodParams: params,
    methodCode: functionCode,
  });

  cases.push({
    title: normalizeTitle(
      isAsync
        ? `${className}.${safeMethodName} checks source-aware result shape asynchronously`
        : `${className}.${safeMethodName} checks source-aware result shape`
    ),
    arrange: methodArrange.arrange,
    act: `instance.${safeMethodName}(${methodArrange.methodArgNames.join(", ")})`,
    assert: buildClassMethodAssertion({
      methodName: safeMethodName,
      methodCode: functionCode,
      methodKind,
      variant: "primary",
    }),
    source: "fallback",
  });

  cases.push({
    title: normalizeTitle(`${className}.${safeMethodName} checks stable result contract`),
    arrange: methodArrange.arrange,
    act: `instance.${safeMethodName}(${methodArrange.methodArgNames.join(", ")})`,
    assert: buildClassMethodAssertion({
      methodName: safeMethodName,
      methodCode: functionCode,
      methodKind,
      variant: "secondary",
    }),
    source: "fallback",
  });

  return cases.slice(0, maxCases);
}

/**
 * Main API used by llmFillTests.js.
 *
 * Returns fallback cases in the same structure as LLM cases:
 * {
 *   title,
 *   arrange,
 *   act,
 *   assert
 * }
 *
 * These cases are intentionally conservative but now source-aware and class-aware.
 */
export function buildFallbackCases({
  fnName,
  params = [],
  isAsync = false,
  isClassLike = false,
  functionCode = "",
  maxCases = MAX_FALLBACK_CASES,

  // Class/method context fields added for class-heavy package support.
  isClassMethod = false,
  ownerClassName = "",
  methodName = "",
  methodKind = "",
  constructorParams = [],
  constructorCode = "",
} = {}) {
  const safeMax = Math.max(0, Math.min(Number(maxCases) || 0, MAX_FALLBACK_CASES));
  if (safeMax === 0) return [];

  /*
   * New class-aware path.
   * This is used after index.js starts creating class method contexts from
   * classExportAnalyzer.js.
   */
  if (isClassMethod || ownerClassName || methodName || methodKind) {
    const finalMethodKind = methodKind || (isClassLike ? "constructor" : "prototype");
    const finalMethodName = methodName || fnName || "constructor";

    if (!ownerClassName && finalMethodKind !== "constructor") {
      return [];
    }

    return buildClassMethodFallbackCases({
      ownerClassName: ownerClassName || fnName,
      methodName: finalMethodName,
      methodKind: finalMethodKind,
      constructorParams,
      constructorCode,
      params,
      functionCode,
      isAsync,
      maxCases: safeMax,
    });
  }

  /*
   * Existing normal function path.
   * Keep class-like constructor fallback available now instead of returning [].
   * This lets class-like exports receive fallback injection safely once
   * llmFillTests.js stops hard-skipping class-like constructor contexts.
   */
  if (!fnName) return [];

  if (isClassLike) {
    return buildConstructorFallbackCases({
      ownerClassName: fnName,
      constructorParams: params,
      constructorCode: functionCode,
      maxCases: safeMax,
    });
  }

  const hasParams = Array.isArray(params) && params.length > 0;

  if (!hasParams) {
    return buildNoParamFallbackCases({
      fnName,
      functionCode,
      maxCases: safeMax,
    });
  }

  return buildParamFallbackCases({
    fnName,
    params,
    isClassLike,
    functionCode,
    isAsync,
    maxCases: safeMax,
  });
}

export function getFallbackCaseLimit() {
  return MAX_FALLBACK_CASES;
}
