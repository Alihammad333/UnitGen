// src/core/testgen/runtimeArtifactCleanup.js

import fs from "fs";
import path from "path";

export function cleanupRuntimeArtifacts(rootDir = process.cwd()) {
  const safeRoot = path.resolve(rootDir);

  const protectedNames = new Set([
    "src",
    "tests",
    "node_modules",
    "benchmark_packages",
    "output",
    "results",
  ]);

  const removableDirPatterns = [
    /^test[a-zA-Z0-9_-]{4,}$/,
    /^temp[a-zA-Z0-9_-]{4,}$/,
    /^custom[a-zA-Z0-9_-]{4,}$/,
    /^data[a-zA-Z0-9_-]{4,}$/,
  ];

  const removableFileNames = new Set([
    "sample",
    "test",
    "arg1",
    "arg2",
    "arg3",
    "unitgen-temp.json",
    "unitgen-temp.txt",
    "temp.json",
    "temp.txt",
  ]);

  let names = [];

  try {
    names = fs.readdirSync(safeRoot);
  } catch {
    return;
  }

  for (const name of names) {
    if (protectedNames.has(name)) continue;

    const fullPath = path.join(safeRoot, name);

    try {
      const stat = fs.statSync(fullPath);

      if (
        stat.isDirectory() &&
        removableDirPatterns.some((pattern) => pattern.test(name))
      ) {
        fs.rmSync(fullPath, { recursive: true, force: true });
        console.log(`🧹 Removed runtime temp artifact: ${name}`);
        continue;
      }

      if (stat.isFile() && removableFileNames.has(name)) {
        fs.rmSync(fullPath, { force: true });
        console.log(`🧹 Removed runtime temp file: ${name}`);
      }
    } catch {
      // never break pipeline because cleanup failed
    }
  }
}
